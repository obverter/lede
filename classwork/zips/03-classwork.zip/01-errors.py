#
# "It doesn't work"
#
# 1. What you're trying to do
# 2. The error message
# 3. The code around where the error is happening
# 4. Expected output
# 5. Actual output
# 6. What you've tried already

# Error
print("Hello world, so full of errors"))

# Error
num = 4.55
print((round(4) * int('5') + 3)

# Error
name = "Roberta"
degres = 14
print("Hello, my name is " + name + " and it is " + degrees "out today")

# Error
name = "Smushface"
print("I have a cat named", Smushface)

# Error
age = 4
if age < 18
    print("You aren't old enough to vote") 

# Error
print("One two three four")
print("Five six seven eight")
print("Nine ten eleven twelve)

# Error
pies = 9
print("You have eaten" + pies + "today")

# Error
current_year = 2013
travel = "future"
cars = True
animal_type = "lions"
if currentyear > 2017:
    print("It's the future!")

# Error
print('4' + '4')

# Error
year = 2017
if year >= 1607:
    print("The American colonies existed")
elif year >= 1776:
    print("The United States exists")
else:
    print("America was just a dream")