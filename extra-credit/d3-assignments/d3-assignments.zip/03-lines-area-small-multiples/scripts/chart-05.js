(function() {
  // Set up margin/height/width

// Add your svg

// Create a time parser (see hints)

// Create your scales

// Create a d3.line function that uses your scales

// Read in your housing price data

// Write your ready function

function ready(datapoints) {
  // Convert your months to dates
  // Get a list of dates and a list of prices
  // Group your data together
  // Draw your lines
  // Add your text on the right-hand side
  // Add your title
  // Add the shaded rectangle
  // Add your axes
}
})()