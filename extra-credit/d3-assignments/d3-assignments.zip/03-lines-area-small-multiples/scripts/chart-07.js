(function() {
    // Create your margins and height/width

// I'll give you this part!
const container = d3.select('#chart-07')

// Create your scales

// Create your line generator

// Read in your data

// Create your ready function
})()