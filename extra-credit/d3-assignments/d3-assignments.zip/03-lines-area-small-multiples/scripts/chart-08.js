(function() {
    // I'll give you margins/height/width
const margin = { top: 100, left: 10, right: 10, bottom: 30 }
const height = 500 - margin.top - margin.bottom
const width = 400 - margin.left - margin.right

// And grabbing your container
const container = d3.select('#chart-08')

// Create your scales

// Create your area generator

// Read in your data, then call ready

// Write your ready function
})()